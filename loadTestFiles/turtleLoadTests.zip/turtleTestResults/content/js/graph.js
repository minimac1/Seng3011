/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
$(document).ready(function() {

    $(".click-title").mouseenter( function(    e){
        e.preventDefault();
        this.style.cursor="pointer";
    });
    $(".click-title").mousedown( function(event){
        event.preventDefault();
    });

    // Ugly code while this script is shared among several pages
    try{
        refreshHitsPerSecond(true);
    } catch(e){}
    try{
        refreshResponseTimeOverTime(true);
    } catch(e){}
    try{
        refreshResponseTimePercentiles();
    } catch(e){}
    $(".portlet-header").css("cursor", "auto");
});

var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

// Fixes time stamps
function fixTimeStamps(series, offset){
    $.each(series, function(index, item) {
        $.each(item.data, function(index, coord) {
            coord[0] += offset;
        });
    });
}

// Check if the specified jquery object is a graph
function isGraph(object){
    return object.data('plot') !== undefined;
}

/**
 * Export graph to a PNG
 */
function exportToPNG(graphName, target) {
    var plot = $("#"+graphName).data('plot');
    var flotCanvas = plot.getCanvas();
    var image = flotCanvas.toDataURL();
    image = image.replace("image/png", "image/octet-stream");
    
    var downloadAttrSupported = ("download" in document.createElement("a"));
    if(downloadAttrSupported === true) {
        target.download = graphName + ".png";
        target.href = image;
    }
    else {
        document.location.href = image;
    }
    
}

// Override the specified graph options to fit the requirements of an overview
function prepareOverviewOptions(graphOptions){
    var overviewOptions = {
        series: {
            shadowSize: 0,
            lines: {
                lineWidth: 1
            },
            points: {
                // Show points on overview only when linked graph does not show
                // lines
                show: getProperty('series.lines.show', graphOptions) == false,
                radius : 1
            }
        },
        xaxis: {
            ticks: 2,
            axisLabel: null
        },
        yaxis: {
            ticks: 2,
            axisLabel: null
        },
        legend: {
            show: false,
            container: null
        },
        grid: {
            hoverable: false
        },
        tooltip: false
    };
    return $.extend(true, {}, graphOptions, overviewOptions);
}

// Force axes boundaries using graph extra options
function prepareOptions(options, data) {
    options.canvas = true;
    var extraOptions = data.extraOptions;
    if(extraOptions !== undefined){
        var xOffset = options.xaxis.mode === "time" ? 36000000 : 0;
        var yOffset = options.yaxis.mode === "time" ? 36000000 : 0;

        if(!isNaN(extraOptions.minX))
        	options.xaxis.min = parseFloat(extraOptions.minX) + xOffset;
        
        if(!isNaN(extraOptions.maxX))
        	options.xaxis.max = parseFloat(extraOptions.maxX) + xOffset;
        
        if(!isNaN(extraOptions.minY))
        	options.yaxis.min = parseFloat(extraOptions.minY) + yOffset;
        
        if(!isNaN(extraOptions.maxY))
        	options.yaxis.max = parseFloat(extraOptions.maxY) + yOffset;
    }
}

// Filter, mark series and sort data
/**
 * @param data
 * @param noMatchColor if defined and true, series.color are not matched with index
 */
function prepareSeries(data, noMatchColor){
    var result = data.result;

    // Keep only series when needed
    if(seriesFilter && (!filtersOnlySampleSeries || result.supportsControllersDiscrimination)){
        // Insensitive case matching
        var regexp = new RegExp(seriesFilter, 'i');
        result.series = $.grep(result.series, function(series, index){
            return regexp.test(series.label);
        });
    }

    // Keep only controllers series when supported and needed
    if(result.supportsControllersDiscrimination && showControllersOnly){
        result.series = $.grep(result.series, function(series, index){
            return series.isController;
        });
    }

    // Sort data and mark series
    $.each(result.series, function(index, series) {
        series.data.sort(compareByXCoordinate);
        if(!(noMatchColor && noMatchColor===true)) {
	        series.color = index;
	    }
    });
}

// Set the zoom on the specified plot object
function zoomPlot(plot, xmin, xmax, ymin, ymax){
    var axes = plot.getAxes();
    // Override axes min and max options
    $.extend(true, axes, {
        xaxis: {
            options : { min: xmin, max: xmax }
        },
        yaxis: {
            options : { min: ymin, max: ymax }
        }
    });

    // Redraw the plot
    plot.setupGrid();
    plot.draw();
}

// Prepares DOM items to add zoom function on the specified graph
function setGraphZoomable(graphSelector, overviewSelector){
    var graph = $(graphSelector);
    var overview = $(overviewSelector);

    // Ignore mouse down event
    graph.bind("mousedown", function() { return false; });
    overview.bind("mousedown", function() { return false; });

    // Zoom on selection
    graph.bind("plotselected", function (event, ranges) {
        // clamp the zooming to prevent infinite zoom
        if (ranges.xaxis.to - ranges.xaxis.from < 0.00001) {
            ranges.xaxis.to = ranges.xaxis.from + 0.00001;
        }
        if (ranges.yaxis.to - ranges.yaxis.from < 0.00001) {
            ranges.yaxis.to = ranges.yaxis.from + 0.00001;
        }

        // Do the zooming
        var plot = graph.data('plot');
        zoomPlot(plot, ranges.xaxis.from, ranges.xaxis.to, ranges.yaxis.from, ranges.yaxis.to);
        plot.clearSelection();

        // Synchronize overview selection
        overview.data('plot').setSelection(ranges, true);
    });

    // Zoom linked graph on overview selection
    overview.bind("plotselected", function (event, ranges) {
        graph.data('plot').setSelection(ranges);
    });

    // Reset linked graph zoom when reseting overview selection
    overview.bind("plotunselected", function () {
        var overviewAxes = overview.data('plot').getAxes();
        zoomPlot(graph.data('plot'), overviewAxes.xaxis.min, overviewAxes.xaxis.max, overviewAxes.yaxis.min, overviewAxes.yaxis.max);
    });
}

var responseTimePercentilesInfos = {
        data: {"result": {"minY": 26.0, "minX": 0.0, "maxY": 41100.0, "series": [{"data": [[0.0, 26.0], [0.1, 26.0], [0.2, 27.0], [0.3, 27.0], [0.4, 27.0], [0.5, 27.0], [0.6, 27.0], [0.7, 27.0], [0.8, 27.0], [0.9, 27.0], [1.0, 27.0], [1.1, 27.0], [1.2, 27.0], [1.3, 28.0], [1.4, 28.0], [1.5, 28.0], [1.6, 28.0], [1.7, 28.0], [1.8, 28.0], [1.9, 28.0], [2.0, 28.0], [2.1, 28.0], [2.2, 28.0], [2.3, 28.0], [2.4, 28.0], [2.5, 29.0], [2.6, 29.0], [2.7, 29.0], [2.8, 29.0], [2.9, 30.0], [3.0, 31.0], [3.1, 35.0], [3.2, 37.0], [3.3, 48.0], [3.4, 48.0], [3.5, 48.0], [3.6, 48.0], [3.7, 48.0], [3.8, 49.0], [3.9, 49.0], [4.0, 49.0], [4.1, 50.0], [4.2, 50.0], [4.3, 60.0], [4.4, 67.0], [4.5, 70.0], [4.6, 87.0], [4.7, 92.0], [4.8, 105.0], [4.9, 116.0], [5.0, 147.0], [5.1, 172.0], [5.2, 177.0], [5.3, 177.0], [5.4, 189.0], [5.5, 236.0], [5.6, 244.0], [5.7, 305.0], [5.8, 476.0], [5.9, 526.0], [6.0, 990.0], [6.1, 1124.0], [6.2, 1131.0], [6.3, 1151.0], [6.4, 1262.0], [6.5, 1264.0], [6.6, 1276.0], [6.7, 1337.0], [6.8, 1345.0], [6.9, 1431.0], [7.0, 1433.0], [7.1, 1462.0], [7.2, 1482.0], [7.3, 1510.0], [7.4, 1519.0], [7.5, 1523.0], [7.6, 1527.0], [7.7, 1531.0], [7.8, 1548.0], [7.9, 1558.0], [8.0, 1563.0], [8.1, 1571.0], [8.2, 1600.0], [8.3, 1616.0], [8.4, 1618.0], [8.5, 1618.0], [8.6, 1639.0], [8.7, 1665.0], [8.8, 1670.0], [8.9, 1694.0], [9.0, 1707.0], [9.1, 1707.0], [9.2, 1708.0], [9.3, 1716.0], [9.4, 1719.0], [9.5, 1728.0], [9.6, 1741.0], [9.7, 1765.0], [9.8, 1767.0], [9.9, 1801.0], [10.0, 1811.0], [10.1, 1830.0], [10.2, 1834.0], [10.3, 1840.0], [10.4, 1840.0], [10.5, 1841.0], [10.6, 1893.0], [10.7, 1903.0], [10.8, 1905.0], [10.9, 1906.0], [11.0, 1922.0], [11.1, 1952.0], [11.2, 1956.0], [11.3, 1968.0], [11.4, 1972.0], [11.5, 2007.0], [11.6, 2007.0], [11.7, 2012.0], [11.8, 2019.0], [11.9, 2031.0], [12.0, 2052.0], [12.1, 2058.0], [12.2, 2069.0], [12.3, 2088.0], [12.4, 2090.0], [12.5, 2092.0], [12.6, 2108.0], [12.7, 2112.0], [12.8, 2115.0], [12.9, 2120.0], [13.0, 2121.0], [13.1, 2124.0], [13.2, 2136.0], [13.3, 2158.0], [13.4, 2160.0], [13.5, 2174.0], [13.6, 2175.0], [13.7, 2201.0], [13.8, 2202.0], [13.9, 2215.0], [14.0, 2216.0], [14.1, 2216.0], [14.2, 2254.0], [14.3, 2287.0], [14.4, 2293.0], [14.5, 2297.0], [14.6, 2311.0], [14.7, 2317.0], [14.8, 2340.0], [14.9, 2357.0], [15.0, 2357.0], [15.1, 2369.0], [15.2, 2369.0], [15.3, 2374.0], [15.4, 2375.0], [15.5, 2379.0], [15.6, 2382.0], [15.7, 2398.0], [15.8, 2398.0], [15.9, 2416.0], [16.0, 2423.0], [16.1, 2442.0], [16.2, 2454.0], [16.3, 2460.0], [16.4, 2467.0], [16.5, 2468.0], [16.6, 2471.0], [16.7, 2474.0], [16.8, 2477.0], [16.9, 2479.0], [17.0, 2488.0], [17.1, 2494.0], [17.2, 2511.0], [17.3, 2513.0], [17.4, 2514.0], [17.5, 2514.0], [17.6, 2522.0], [17.7, 2530.0], [17.8, 2532.0], [17.9, 2533.0], [18.0, 2553.0], [18.1, 2554.0], [18.2, 2569.0], [18.3, 2586.0], [18.4, 2589.0], [18.5, 2606.0], [18.6, 2631.0], [18.7, 2647.0], [18.8, 2662.0], [18.9, 2674.0], [19.0, 2675.0], [19.1, 2688.0], [19.2, 2688.0], [19.3, 2725.0], [19.4, 2727.0], [19.5, 2729.0], [19.6, 2734.0], [19.7, 2747.0], [19.8, 2761.0], [19.9, 2766.0], [20.0, 2771.0], [20.1, 2774.0], [20.2, 2784.0], [20.3, 2789.0], [20.4, 2793.0], [20.5, 2806.0], [20.6, 2822.0], [20.7, 2828.0], [20.8, 2835.0], [20.9, 2854.0], [21.0, 2879.0], [21.1, 2886.0], [21.2, 2902.0], [21.3, 2905.0], [21.4, 2928.0], [21.5, 2929.0], [21.6, 2934.0], [21.7, 2935.0], [21.8, 2962.0], [21.9, 2963.0], [22.0, 2969.0], [22.1, 2985.0], [22.2, 2995.0], [22.3, 3013.0], [22.4, 3016.0], [22.5, 3021.0], [22.6, 3029.0], [22.7, 3029.0], [22.8, 3033.0], [22.9, 3038.0], [23.0, 3044.0], [23.1, 3049.0], [23.2, 3050.0], [23.3, 3054.0], [23.4, 3056.0], [23.5, 3062.0], [23.6, 3070.0], [23.7, 3079.0], [23.8, 3084.0], [23.9, 3097.0], [24.0, 3100.0], [24.1, 3107.0], [24.2, 3108.0], [24.3, 3112.0], [24.4, 3139.0], [24.5, 3152.0], [24.6, 3155.0], [24.7, 3157.0], [24.8, 3185.0], [24.9, 3189.0], [25.0, 3197.0], [25.1, 3233.0], [25.2, 3246.0], [25.3, 3305.0], [25.4, 3305.0], [25.5, 3326.0], [25.6, 3357.0], [25.7, 3357.0], [25.8, 3361.0], [25.9, 3361.0], [26.0, 3382.0], [26.1, 3387.0], [26.2, 3396.0], [26.3, 3397.0], [26.4, 3417.0], [26.5, 3426.0], [26.6, 3430.0], [26.7, 3434.0], [26.8, 3458.0], [26.9, 3462.0], [27.0, 3462.0], [27.1, 3463.0], [27.2, 3472.0], [27.3, 3474.0], [27.4, 3494.0], [27.5, 3497.0], [27.6, 3499.0], [27.7, 3507.0], [27.8, 3515.0], [27.9, 3522.0], [28.0, 3540.0], [28.1, 3543.0], [28.2, 3546.0], [28.3, 3553.0], [28.4, 3567.0], [28.5, 3576.0], [28.6, 3602.0], [28.7, 3605.0], [28.8, 3607.0], [28.9, 3618.0], [29.0, 3624.0], [29.1, 3637.0], [29.2, 3643.0], [29.3, 3661.0], [29.4, 3675.0], [29.5, 3690.0], [29.6, 3693.0], [29.7, 3693.0], [29.8, 3694.0], [29.9, 3700.0], [30.0, 3729.0], [30.1, 3749.0], [30.2, 3750.0], [30.3, 3760.0], [30.4, 3770.0], [30.5, 3789.0], [30.6, 3798.0], [30.7, 3802.0], [30.8, 3810.0], [30.9, 3814.0], [31.0, 3824.0], [31.1, 3847.0], [31.2, 3903.0], [31.3, 3908.0], [31.4, 3911.0], [31.5, 3917.0], [31.6, 3921.0], [31.7, 3929.0], [31.8, 3956.0], [31.9, 3971.0], [32.0, 3993.0], [32.1, 4020.0], [32.2, 4043.0], [32.3, 4051.0], [32.4, 4067.0], [32.5, 4090.0], [32.6, 4102.0], [32.7, 4104.0], [32.8, 4118.0], [32.9, 4144.0], [33.0, 4149.0], [33.1, 4162.0], [33.2, 4200.0], [33.3, 4221.0], [33.4, 4221.0], [33.5, 4228.0], [33.6, 4279.0], [33.7, 4293.0], [33.8, 4303.0], [33.9, 4309.0], [34.0, 4311.0], [34.1, 4318.0], [34.2, 4373.0], [34.3, 4380.0], [34.4, 4394.0], [34.5, 4440.0], [34.6, 4456.0], [34.7, 4489.0], [34.8, 4513.0], [34.9, 4530.0], [35.0, 4536.0], [35.1, 4554.0], [35.2, 4588.0], [35.3, 4597.0], [35.4, 4609.0], [35.5, 4668.0], [35.6, 4716.0], [35.7, 4730.0], [35.8, 4736.0], [35.9, 4746.0], [36.0, 4763.0], [36.1, 4842.0], [36.2, 4843.0], [36.3, 4855.0], [36.4, 4860.0], [36.5, 4904.0], [36.6, 4941.0], [36.7, 4945.0], [36.8, 4968.0], [36.9, 4973.0], [37.0, 4983.0], [37.1, 4995.0], [37.2, 5019.0], [37.3, 5058.0], [37.4, 5073.0], [37.5, 5078.0], [37.6, 5084.0], [37.7, 5102.0], [37.8, 5135.0], [37.9, 5136.0], [38.0, 5136.0], [38.1, 5170.0], [38.2, 5171.0], [38.3, 5189.0], [38.4, 5221.0], [38.5, 5226.0], [38.6, 5330.0], [38.7, 5361.0], [38.8, 5372.0], [38.9, 5381.0], [39.0, 5383.0], [39.1, 5408.0], [39.2, 5449.0], [39.3, 5467.0], [39.4, 5587.0], [39.5, 5747.0], [39.6, 5843.0], [39.7, 5858.0], [39.8, 6013.0], [39.9, 6016.0], [40.0, 6018.0], [40.1, 6100.0], [40.2, 6123.0], [40.3, 6125.0], [40.4, 6187.0], [40.5, 6223.0], [40.6, 6327.0], [40.7, 6340.0], [40.8, 6357.0], [40.9, 6363.0], [41.0, 6381.0], [41.1, 6385.0], [41.2, 6394.0], [41.3, 6411.0], [41.4, 6414.0], [41.5, 6482.0], [41.6, 6507.0], [41.7, 6520.0], [41.8, 6527.0], [41.9, 6606.0], [42.0, 6707.0], [42.1, 6737.0], [42.2, 6846.0], [42.3, 7030.0], [42.4, 7043.0], [42.5, 7049.0], [42.6, 7078.0], [42.7, 7089.0], [42.8, 7296.0], [42.9, 7310.0], [43.0, 7373.0], [43.1, 7433.0], [43.2, 7446.0], [43.3, 7545.0], [43.4, 7553.0], [43.5, 7564.0], [43.6, 7600.0], [43.7, 7658.0], [43.8, 7670.0], [43.9, 7693.0], [44.0, 7716.0], [44.1, 7721.0], [44.2, 7753.0], [44.3, 7818.0], [44.4, 7842.0], [44.5, 7933.0], [44.6, 8070.0], [44.7, 8073.0], [44.8, 8093.0], [44.9, 8104.0], [45.0, 8155.0], [45.1, 8202.0], [45.2, 8215.0], [45.3, 8382.0], [45.4, 8451.0], [45.5, 8464.0], [45.6, 8514.0], [45.7, 8544.0], [45.8, 8549.0], [45.9, 8573.0], [46.0, 8579.0], [46.1, 8620.0], [46.2, 8624.0], [46.3, 8625.0], [46.4, 8636.0], [46.5, 8677.0], [46.6, 8687.0], [46.7, 8754.0], [46.8, 8763.0], [46.9, 8763.0], [47.0, 8803.0], [47.1, 8847.0], [47.2, 8857.0], [47.3, 8888.0], [47.4, 8935.0], [47.5, 9014.0], [47.6, 9039.0], [47.7, 9055.0], [47.8, 9081.0], [47.9, 9101.0], [48.0, 9197.0], [48.1, 9228.0], [48.2, 9268.0], [48.3, 9280.0], [48.4, 9302.0], [48.5, 9375.0], [48.6, 9380.0], [48.7, 9441.0], [48.8, 9463.0], [48.9, 9467.0], [49.0, 9470.0], [49.1, 9474.0], [49.2, 9511.0], [49.3, 9542.0], [49.4, 9563.0], [49.5, 9577.0], [49.6, 9629.0], [49.7, 9652.0], [49.8, 9652.0], [49.9, 9674.0], [50.0, 9678.0], [50.1, 9694.0], [50.2, 9723.0], [50.3, 9730.0], [50.4, 9737.0], [50.5, 9746.0], [50.6, 9756.0], [50.7, 9757.0], [50.8, 9794.0], [50.9, 9812.0], [51.0, 9840.0], [51.1, 9841.0], [51.2, 9842.0], [51.3, 9846.0], [51.4, 9847.0], [51.5, 9867.0], [51.6, 9926.0], [51.7, 9932.0], [51.8, 9960.0], [51.9, 9960.0], [52.0, 9972.0], [52.1, 9980.0], [52.2, 9990.0], [52.3, 10004.0], [52.4, 10006.0], [52.5, 10020.0], [52.6, 10021.0], [52.7, 10029.0], [52.8, 10030.0], [52.9, 10041.0], [53.0, 10049.0], [53.1, 10059.0], [53.2, 10067.0], [53.3, 10072.0], [53.4, 10083.0], [53.5, 10089.0], [53.6, 10111.0], [53.7, 10135.0], [53.8, 10166.0], [53.9, 10174.0], [54.0, 10238.0], [54.1, 10241.0], [54.2, 10270.0], [54.3, 10284.0], [54.4, 10292.0], [54.5, 10341.0], [54.6, 10427.0], [54.7, 10461.0], [54.8, 10498.0], [54.9, 10524.0], [55.0, 10526.0], [55.1, 10538.0], [55.2, 10544.0], [55.3, 10612.0], [55.4, 10618.0], [55.5, 10666.0], [55.6, 10678.0], [55.7, 10692.0], [55.8, 10715.0], [55.9, 10718.0], [56.0, 10727.0], [56.1, 10748.0], [56.2, 10757.0], [56.3, 10757.0], [56.4, 10783.0], [56.5, 10783.0], [56.6, 10789.0], [56.7, 10798.0], [56.8, 10832.0], [56.9, 10842.0], [57.0, 10860.0], [57.1, 10899.0], [57.2, 10912.0], [57.3, 10952.0], [57.4, 10961.0], [57.5, 10963.0], [57.6, 10983.0], [57.7, 11015.0], [57.8, 11051.0], [57.9, 11058.0], [58.0, 11107.0], [58.1, 11127.0], [58.2, 11141.0], [58.3, 11153.0], [58.4, 11169.0], [58.5, 11197.0], [58.6, 11257.0], [58.7, 11269.0], [58.8, 11282.0], [58.9, 11287.0], [59.0, 11292.0], [59.1, 11296.0], [59.2, 11337.0], [59.3, 11405.0], [59.4, 11408.0], [59.5, 11444.0], [59.6, 11513.0], [59.7, 11514.0], [59.8, 11524.0], [59.9, 11549.0], [60.0, 11571.0], [60.1, 11600.0], [60.2, 11638.0], [60.3, 11643.0], [60.4, 11663.0], [60.5, 11682.0], [60.6, 11698.0], [60.7, 11739.0], [60.8, 11741.0], [60.9, 11799.0], [61.0, 11828.0], [61.1, 11853.0], [61.2, 11868.0], [61.3, 11923.0], [61.4, 11959.0], [61.5, 11998.0], [61.6, 12011.0], [61.7, 12017.0], [61.8, 12043.0], [61.9, 12176.0], [62.0, 12221.0], [62.1, 12272.0], [62.2, 12313.0], [62.3, 12401.0], [62.4, 12529.0], [62.5, 12562.0], [62.6, 12582.0], [62.7, 12594.0], [62.8, 12644.0], [62.9, 12689.0], [63.0, 12795.0], [63.1, 12822.0], [63.2, 12920.0], [63.3, 12921.0], [63.4, 12937.0], [63.5, 12957.0], [63.6, 13023.0], [63.7, 13068.0], [63.8, 13082.0], [63.9, 13091.0], [64.0, 13149.0], [64.1, 13188.0], [64.2, 13252.0], [64.3, 13277.0], [64.4, 13304.0], [64.5, 13403.0], [64.6, 13447.0], [64.7, 13471.0], [64.8, 13596.0], [64.9, 13661.0], [65.0, 13697.0], [65.1, 13811.0], [65.2, 13830.0], [65.3, 13848.0], [65.4, 13888.0], [65.5, 14251.0], [65.6, 14268.0], [65.7, 14396.0], [65.8, 14444.0], [65.9, 14450.0], [66.0, 14543.0], [66.1, 14580.0], [66.2, 14583.0], [66.3, 14626.0], [66.4, 14627.0], [66.5, 14681.0], [66.6, 14729.0], [66.7, 14732.0], [66.8, 14905.0], [66.9, 15168.0], [67.0, 15287.0], [67.1, 15321.0], [67.2, 15387.0], [67.3, 15401.0], [67.4, 15408.0], [67.5, 15502.0], [67.6, 15596.0], [67.7, 15654.0], [67.8, 15720.0], [67.9, 15727.0], [68.0, 15742.0], [68.1, 15784.0], [68.2, 15901.0], [68.3, 15927.0], [68.4, 15945.0], [68.5, 16003.0], [68.6, 16103.0], [68.7, 16119.0], [68.8, 16201.0], [68.9, 16220.0], [69.0, 16307.0], [69.1, 16367.0], [69.2, 16476.0], [69.3, 16495.0], [69.4, 16504.0], [69.5, 16559.0], [69.6, 16570.0], [69.7, 16571.0], [69.8, 16597.0], [69.9, 16676.0], [70.0, 16809.0], [70.1, 16931.0], [70.2, 16999.0], [70.3, 17040.0], [70.4, 17251.0], [70.5, 17253.0], [70.6, 17273.0], [70.7, 17354.0], [70.8, 17408.0], [70.9, 17446.0], [71.0, 17671.0], [71.1, 17683.0], [71.2, 17708.0], [71.3, 17780.0], [71.4, 17809.0], [71.5, 17875.0], [71.6, 17895.0], [71.7, 18249.0], [71.8, 18258.0], [71.9, 18282.0], [72.0, 18587.0], [72.1, 18603.0], [72.2, 18745.0], [72.3, 19023.0], [72.4, 19039.0], [72.5, 19111.0], [72.6, 19133.0], [72.7, 19197.0], [72.8, 19249.0], [72.9, 19268.0], [73.0, 19295.0], [73.1, 19450.0], [73.2, 19478.0], [73.3, 19486.0], [73.4, 19733.0], [73.5, 19920.0], [73.6, 19924.0], [73.7, 20015.0], [73.8, 20136.0], [73.9, 20153.0], [74.0, 20241.0], [74.1, 20453.0], [74.2, 20489.0], [74.3, 20550.0], [74.4, 20559.0], [74.5, 20574.0], [74.6, 20695.0], [74.7, 21139.0], [74.8, 21224.0], [74.9, 21278.0], [75.0, 21323.0], [75.1, 21363.0], [75.2, 21419.0], [75.3, 21428.0], [75.4, 21581.0], [75.5, 21603.0], [75.6, 21606.0], [75.7, 21674.0], [75.8, 21788.0], [75.9, 21818.0], [76.0, 21832.0], [76.1, 21832.0], [76.2, 21874.0], [76.3, 21909.0], [76.4, 21949.0], [76.5, 22000.0], [76.6, 22023.0], [76.7, 22107.0], [76.8, 22213.0], [76.9, 22281.0], [77.0, 22293.0], [77.1, 22386.0], [77.2, 22569.0], [77.3, 22714.0], [77.4, 22817.0], [77.5, 22846.0], [77.6, 22876.0], [77.7, 23083.0], [77.8, 23128.0], [77.9, 23176.0], [78.0, 23196.0], [78.1, 23235.0], [78.2, 23315.0], [78.3, 23325.0], [78.4, 23426.0], [78.5, 23441.0], [78.6, 23741.0], [78.7, 23770.0], [78.8, 23838.0], [78.9, 23840.0], [79.0, 23851.0], [79.1, 23960.0], [79.2, 24050.0], [79.3, 24210.0], [79.4, 24352.0], [79.5, 24368.0], [79.6, 24426.0], [79.7, 24565.0], [79.8, 24587.0], [79.9, 24829.0], [80.0, 24830.0], [80.1, 24836.0], [80.2, 24893.0], [80.3, 24907.0], [80.4, 24963.0], [80.5, 24963.0], [80.6, 24984.0], [80.7, 25087.0], [80.8, 25227.0], [80.9, 25278.0], [81.0, 25329.0], [81.1, 25484.0], [81.2, 25577.0], [81.3, 25629.0], [81.4, 25804.0], [81.5, 25913.0], [81.6, 25922.0], [81.7, 25955.0], [81.8, 26042.0], [81.9, 26145.0], [82.0, 26168.0], [82.1, 26239.0], [82.2, 26353.0], [82.3, 26467.0], [82.4, 26480.0], [82.5, 26495.0], [82.6, 26604.0], [82.7, 26686.0], [82.8, 26757.0], [82.9, 26783.0], [83.0, 26813.0], [83.1, 26840.0], [83.2, 26901.0], [83.3, 26919.0], [83.4, 26999.0], [83.5, 27042.0], [83.6, 27052.0], [83.7, 27102.0], [83.8, 27150.0], [83.9, 27163.0], [84.0, 27173.0], [84.1, 27218.0], [84.2, 27345.0], [84.3, 27362.0], [84.4, 27393.0], [84.5, 27396.0], [84.6, 27537.0], [84.7, 27688.0], [84.8, 27705.0], [84.9, 27744.0], [85.0, 27915.0], [85.1, 28008.0], [85.2, 28086.0], [85.3, 28089.0], [85.4, 28103.0], [85.5, 28137.0], [85.6, 28166.0], [85.7, 28169.0], [85.8, 28214.0], [85.9, 28256.0], [86.0, 28301.0], [86.1, 28468.0], [86.2, 28488.0], [86.3, 28595.0], [86.4, 28639.0], [86.5, 28696.0], [86.6, 28770.0], [86.7, 28783.0], [86.8, 28784.0], [86.9, 28881.0], [87.0, 28883.0], [87.1, 29068.0], [87.2, 29081.0], [87.3, 29182.0], [87.4, 29381.0], [87.5, 29429.0], [87.6, 29587.0], [87.7, 29590.0], [87.8, 29591.0], [87.9, 29643.0], [88.0, 29650.0], [88.1, 29767.0], [88.2, 29779.0], [88.3, 29948.0], [88.4, 30005.0], [88.5, 30175.0], [88.6, 30260.0], [88.7, 30351.0], [88.8, 30473.0], [88.9, 30508.0], [89.0, 30643.0], [89.1, 30723.0], [89.2, 30742.0], [89.3, 30900.0], [89.4, 30918.0], [89.5, 30959.0], [89.6, 30990.0], [89.7, 31032.0], [89.8, 31044.0], [89.9, 31173.0], [90.0, 31176.0], [90.1, 31211.0], [90.2, 31327.0], [90.3, 31370.0], [90.4, 31388.0], [90.5, 32004.0], [90.6, 32042.0], [90.7, 32068.0], [90.8, 32068.0], [90.9, 32093.0], [91.0, 32118.0], [91.1, 32119.0], [91.2, 32278.0], [91.3, 32284.0], [91.4, 32408.0], [91.5, 32410.0], [91.6, 32415.0], [91.7, 32450.0], [91.8, 32543.0], [91.9, 32572.0], [92.0, 32693.0], [92.1, 32868.0], [92.2, 33027.0], [92.3, 33056.0], [92.4, 33183.0], [92.5, 33192.0], [92.6, 33204.0], [92.7, 33293.0], [92.8, 33323.0], [92.9, 33352.0], [93.0, 33587.0], [93.1, 33598.0], [93.2, 33639.0], [93.3, 33641.0], [93.4, 33765.0], [93.5, 33782.0], [93.6, 33912.0], [93.7, 33919.0], [93.8, 33928.0], [93.9, 33945.0], [94.0, 33952.0], [94.1, 33966.0], [94.2, 34012.0], [94.3, 34100.0], [94.4, 34138.0], [94.5, 34153.0], [94.6, 34253.0], [94.7, 34325.0], [94.8, 34367.0], [94.9, 34399.0], [95.0, 34403.0], [95.1, 34571.0], [95.2, 34614.0], [95.3, 34627.0], [95.4, 34859.0], [95.5, 34884.0], [95.6, 35058.0], [95.7, 35259.0], [95.8, 35368.0], [95.9, 35381.0], [96.0, 35385.0], [96.1, 35524.0], [96.2, 35543.0], [96.3, 35813.0], [96.4, 35820.0], [96.5, 35885.0], [96.6, 35995.0], [96.7, 36000.0], [96.8, 36059.0], [96.9, 36244.0], [97.0, 36398.0], [97.1, 36481.0], [97.2, 36559.0], [97.3, 36562.0], [97.4, 36656.0], [97.5, 36682.0], [97.6, 36721.0], [97.7, 36836.0], [97.8, 36875.0], [97.9, 36883.0], [98.0, 36951.0], [98.1, 37187.0], [98.2, 37199.0], [98.3, 37314.0], [98.4, 37331.0], [98.5, 37450.0], [98.6, 37466.0], [98.7, 37666.0], [98.8, 37676.0], [98.9, 37832.0], [99.0, 37920.0], [99.1, 37958.0], [99.2, 38164.0], [99.3, 38317.0], [99.4, 38670.0], [99.5, 38836.0], [99.6, 39196.0], [99.7, 39442.0], [99.8, 40747.0], [99.9, 41100.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 100.0, "title": "Response Time Percentiles"}},
        getOptions: function() {
            return {
                series: {
                    points: { show: false }
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentiles'
                },
                xaxis: {
                    tickDecimals: 1,
                    axisLabel: "Percentiles",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Percentile value in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : %x.2 percentile was %y ms"
                },
                selection: { mode: "xy" },
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentiles"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesPercentiles"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesPercentiles"), dataset, prepareOverviewOptions(options));
        }
};

// Response times percentiles
function refreshResponseTimePercentiles() {
    var infos = responseTimePercentilesInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimesPercentiles"))){
        infos.createGraph();
    } else {
        var choiceContainer = $("#choicesResponseTimePercentiles");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesPercentiles", "#overviewResponseTimesPercentiles");
        $('#bodyResponseTimePercentiles .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimeDistributionInfos = {
        data: {"result": {"minY": 1.0, "minX": 0.0, "maxY": 48.0, "series": [{"data": [[0.0, 48.0], [100.0, 7.0], [33700.0, 2.0], [33300.0, 2.0], [34100.0, 3.0], [34500.0, 1.0], [35300.0, 3.0], [36500.0, 2.0], [36900.0, 1.0], [37300.0, 2.0], [38100.0, 1.0], [200.0, 2.0], [300.0, 1.0], [400.0, 1.0], [500.0, 1.0], [900.0, 1.0], [1100.0, 3.0], [1200.0, 3.0], [1300.0, 2.0], [1400.0, 4.0], [1500.0, 9.0], [1600.0, 8.0], [1700.0, 9.0], [1800.0, 8.0], [1900.0, 8.0], [2000.0, 11.0], [2100.0, 11.0], [2200.0, 9.0], [2300.0, 13.0], [2400.0, 13.0], [2500.0, 13.0], [2600.0, 7.0], [2800.0, 7.0], [2700.0, 12.0], [2900.0, 11.0], [3000.0, 17.0], [3100.0, 11.0], [3300.0, 11.0], [3200.0, 2.0], [3400.0, 13.0], [3500.0, 9.0], [3600.0, 13.0], [3700.0, 8.0], [3800.0, 5.0], [3900.0, 9.0], [4000.0, 5.0], [4100.0, 6.0], [4200.0, 6.0], [4300.0, 7.0], [4500.0, 6.0], [4600.0, 2.0], [4400.0, 3.0], [4800.0, 4.0], [4700.0, 5.0], [5000.0, 5.0], [5100.0, 7.0], [4900.0, 7.0], [5200.0, 2.0], [5300.0, 5.0], [5400.0, 3.0], [5500.0, 1.0], [5800.0, 2.0], [5700.0, 1.0], [6000.0, 3.0], [6100.0, 4.0], [6300.0, 7.0], [6200.0, 1.0], [6500.0, 3.0], [6400.0, 3.0], [6600.0, 1.0], [6800.0, 1.0], [6700.0, 2.0], [7000.0, 5.0], [7300.0, 2.0], [7200.0, 1.0], [7400.0, 2.0], [7600.0, 4.0], [7500.0, 3.0], [7800.0, 2.0], [7700.0, 3.0], [7900.0, 1.0], [8100.0, 2.0], [8000.0, 3.0], [8700.0, 3.0], [8600.0, 6.0], [8500.0, 5.0], [8200.0, 2.0], [8400.0, 2.0], [8300.0, 1.0], [8800.0, 4.0], [9200.0, 3.0], [9100.0, 2.0], [9000.0, 4.0], [8900.0, 1.0], [9300.0, 3.0], [9400.0, 5.0], [9600.0, 6.0], [9700.0, 7.0], [9500.0, 4.0], [9800.0, 7.0], [10000.0, 13.0], [9900.0, 7.0], [10200.0, 5.0], [10100.0, 4.0], [10300.0, 1.0], [10500.0, 4.0], [10700.0, 10.0], [10600.0, 5.0], [10400.0, 3.0], [10800.0, 4.0], [11000.0, 3.0], [11100.0, 6.0], [11200.0, 6.0], [10900.0, 5.0], [11400.0, 3.0], [11700.0, 3.0], [11500.0, 5.0], [11600.0, 6.0], [11300.0, 1.0], [11900.0, 3.0], [12000.0, 3.0], [12200.0, 2.0], [11800.0, 3.0], [12100.0, 1.0], [12300.0, 1.0], [12500.0, 4.0], [12600.0, 2.0], [12700.0, 1.0], [12400.0, 1.0], [13000.0, 4.0], [12900.0, 4.0], [13200.0, 2.0], [13100.0, 2.0], [13300.0, 1.0], [12800.0, 1.0], [13600.0, 2.0], [13800.0, 4.0], [13400.0, 3.0], [13500.0, 1.0], [14200.0, 2.0], [14300.0, 1.0], [14500.0, 3.0], [14600.0, 3.0], [14400.0, 2.0], [14700.0, 2.0], [15200.0, 1.0], [15100.0, 1.0], [15300.0, 2.0], [14900.0, 1.0], [15600.0, 1.0], [15700.0, 4.0], [15500.0, 2.0], [15400.0, 2.0], [16100.0, 2.0], [16300.0, 2.0], [15900.0, 3.0], [16000.0, 1.0], [16200.0, 2.0], [16400.0, 2.0], [16800.0, 1.0], [17400.0, 2.0], [17000.0, 1.0], [16600.0, 1.0], [17200.0, 3.0], [18200.0, 3.0], [17600.0, 2.0], [17800.0, 3.0], [19000.0, 2.0], [19400.0, 3.0], [19200.0, 3.0], [18600.0, 1.0], [20400.0, 2.0], [20000.0, 1.0], [20200.0, 1.0], [20600.0, 1.0], [21000.0, 1.0], [21400.0, 2.0], [21200.0, 2.0], [21600.0, 3.0], [22200.0, 3.0], [21800.0, 4.0], [22000.0, 2.0], [22800.0, 3.0], [23400.0, 2.0], [23200.0, 1.0], [23000.0, 1.0], [24000.0, 1.0], [24200.0, 1.0], [23800.0, 3.0], [24400.0, 1.0], [24800.0, 4.0], [25200.0, 2.0], [25000.0, 1.0], [25400.0, 1.0], [26200.0, 1.0], [25600.0, 1.0], [26000.0, 1.0], [25800.0, 1.0], [26400.0, 3.0], [26600.0, 2.0], [27200.0, 1.0], [26800.0, 2.0], [27000.0, 2.0], [27600.0, 1.0], [28200.0, 2.0], [28400.0, 2.0], [28000.0, 3.0], [28600.0, 2.0], [29000.0, 2.0], [28800.0, 2.0], [29600.0, 2.0], [29400.0, 1.0], [30400.0, 1.0], [30600.0, 1.0], [30000.0, 1.0], [30200.0, 1.0], [31000.0, 2.0], [31200.0, 1.0], [32000.0, 5.0], [32400.0, 4.0], [32200.0, 2.0], [32600.0, 1.0], [32800.0, 1.0], [33200.0, 2.0], [33600.0, 2.0], [34800.0, 2.0], [34400.0, 1.0], [34000.0, 1.0], [35200.0, 1.0], [36400.0, 1.0], [36000.0, 2.0], [36800.0, 3.0], [37600.0, 2.0], [38800.0, 1.0], [33500.0, 2.0], [33900.0, 6.0], [33100.0, 2.0], [34300.0, 3.0], [35500.0, 2.0], [35900.0, 1.0], [36700.0, 1.0], [36300.0, 1.0], [37100.0, 2.0], [37900.0, 2.0], [38300.0, 1.0], [39100.0, 1.0], [40700.0, 1.0], [41100.0, 1.0], [16500.0, 5.0], [16900.0, 2.0], [17300.0, 1.0], [17700.0, 2.0], [18500.0, 1.0], [19100.0, 3.0], [18700.0, 1.0], [19900.0, 2.0], [20100.0, 2.0], [19700.0, 1.0], [20500.0, 3.0], [21100.0, 1.0], [21500.0, 1.0], [21300.0, 2.0], [21700.0, 1.0], [21900.0, 2.0], [22500.0, 1.0], [22300.0, 1.0], [22100.0, 1.0], [22700.0, 1.0], [23100.0, 3.0], [23300.0, 2.0], [23700.0, 2.0], [24500.0, 2.0], [23900.0, 1.0], [24300.0, 2.0], [24900.0, 4.0], [25300.0, 1.0], [25500.0, 1.0], [25900.0, 3.0], [26300.0, 1.0], [26100.0, 2.0], [26900.0, 3.0], [27300.0, 4.0], [27100.0, 4.0], [26700.0, 2.0], [27500.0, 1.0], [28500.0, 1.0], [27700.0, 2.0], [28100.0, 4.0], [28300.0, 1.0], [27900.0, 1.0], [28700.0, 3.0], [29500.0, 3.0], [29100.0, 1.0], [29300.0, 1.0], [30500.0, 1.0], [29900.0, 1.0], [29700.0, 2.0], [30700.0, 2.0], [30300.0, 1.0], [30100.0, 1.0], [30900.0, 4.0], [31100.0, 2.0], [31300.0, 3.0], [32500.0, 2.0], [32100.0, 2.0], [33000.0, 2.0], [34200.0, 1.0], [34600.0, 2.0], [35000.0, 1.0], [36600.0, 2.0], [35800.0, 3.0], [36200.0, 1.0], [38600.0, 1.0], [37400.0, 2.0], [37800.0, 1.0], [39400.0, 1.0]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 100, "maxX": 41100.0, "title": "Response Time Distribution"}},
        getOptions: function() {
            var granularity = this.data.result.granularity;
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    barWidth: this.data.result.granularity
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " responses for " + label + " were between " + xval + " and " + (xval + granularity) + " ms";
                    }
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimeDistribution"), prepareData(data.result.series, $("#choicesResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshResponseTimeDistribution() {
    var infos = responseTimeDistributionInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var syntheticResponseTimeDistributionInfos = {
        data: {"result": {"minY": 9.0, "minX": 1.0, "ticks": [[0, "Requests having \nresponse time <= 500ms"], [1, "Requests having \nresponse time > 500ms and <= 1,500ms"], [2, "Requests having \nresponse time > 1,500ms"], [3, "Requests in error"]], "maxY": 917.0, "series": [{"data": [[1.0, 9.0]], "isOverall": false, "label": "Requests having \nresponse time > 500ms and <= 1,500ms", "isController": false}, {"data": [[3.0, 74.0]], "isOverall": false, "label": "Requests in error", "isController": false}, {"data": [[2.0, 917.0]], "isOverall": false, "label": "Requests having \nresponse time > 1,500ms", "isController": false}], "supportsControllersDiscrimination": false, "maxX": 3.0, "title": "Synthetic Response Times Distribution"}},
        getOptions: function() {
            return {
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendSyntheticResponseTimeDistribution'
                },
                xaxis:{
                    axisLabel: "Response times ranges",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                    tickLength:0,
                    min:-0.5,
                    max:3.5
                },
                yaxis: {
                    axisLabel: "Number of responses",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                bars : {
                    show: true,
                    align: "center",
                    barWidth: 0.25,
                    fill:.75
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: function(label, xval, yval, flotItem){
                        return yval + " " + label;
                    }
                },
                colors: ["#9ACD32", "yellow", "orange", "#FF6347"]                
            };
        },
        createGraph: function() {
            var data = this.data;
            var options = this.getOptions();
            prepareOptions(options, data);
            options.xaxis.ticks = data.result.ticks;
            $.plot($("#flotSyntheticResponseTimeDistribution"), prepareData(data.result.series, $("#choicesSyntheticResponseTimeDistribution")), options);
        }

};

// Response time distribution
function refreshSyntheticResponseTimeDistribution() {
    var infos = syntheticResponseTimeDistributionInfos;
    prepareSeries(infos.data, true);
    if (isGraph($("#flotSyntheticResponseTimeDistribution"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        $('#footerSyntheticResponseTimeDistribution .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var activeThreadsOverTimeInfos = {
        data: {"result": {"minY": 11.323353293413176, "minX": 1.52480334E12, "maxY": 89.67578125, "series": [{"data": [[1.52480352E12, 89.67578125], [1.52480358E12, 45.873239436619706], [1.5248034E12, 23.841836734693885], [1.52480346E12, 62.82738095238094], [1.52480334E12, 11.323353293413176]], "isOverall": false, "label": "Thread Group", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.52480358E12, "title": "Active Threads Over Time"}},
        getOptions: function() {
            return {
                series: {
                    stack: true,
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 6,
                    show: true,
                    container: '#legendActiveThreadsOverTime'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                selection: {
                    mode: 'xy'
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : At %x there were %y active threads"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesActiveThreadsOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotActiveThreadsOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewActiveThreadsOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Active Threads Over Time
function refreshActiveThreadsOverTime(fixTimestamps) {
    var infos = activeThreadsOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 36000000);
    }
    if(isGraph($("#flotActiveThreadsOverTime"))) {
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesActiveThreadsOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotActiveThreadsOverTime", "#overviewActiveThreadsOverTime");
        $('#footerActiveThreadsOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var timeVsThreadsInfos = {
        data: {"result": {"minY": 27.0, "minX": 1.0, "maxY": 28743.4, "series": [{"data": [[2.0, 1536.5], [3.0, 1589.0], [4.0, 1556.75], [5.0, 1904.5], [6.0, 1835.0], [7.0, 1990.6000000000001], [8.0, 1852.0], [9.0, 2091.666666666667], [10.0, 2330.578947368421], [11.0, 2428.2222222222226], [12.0, 2697.4615384615386], [13.0, 2747.2941176470595], [14.0, 3243.25], [15.0, 3290.9047619047624], [16.0, 3470.4210526315787], [17.0, 3800.5666666666666], [18.0, 3797.483870967742], [19.0, 3592.7241379310344], [20.0, 4646.181818181819], [21.0, 5329.2], [22.0, 5979.857142857142], [23.0, 6297.25], [24.0, 7445.428571428572], [25.0, 7286.25], [26.0, 6113.714285714286], [27.0, 4763.0], [28.0, 7928.9375], [29.0, 9491.818181818182], [30.0, 9264.285714285716], [31.0, 8455.666666666666], [32.0, 8285.666666666666], [33.0, 8900.666666666668], [34.0, 10027.625], [35.0, 10186.083333333332], [36.0, 9846.4], [37.0, 8854.666666666668], [38.0, 10267.5], [39.0, 10184.5], [40.0, 11258.166666666668], [41.0, 10823.833333333334], [42.0, 11842.88888888889], [43.0, 10980.0], [44.0, 11603.714285714286], [45.0, 12362.0], [47.0, 11999.42857142857], [46.0, 12392.0], [48.0, 11979.333333333336], [49.0, 9748.571428571428], [50.0, 12233.384615384613], [51.0, 14710.9], [52.0, 12587.6], [53.0, 14125.0], [54.0, 11598.2], [55.0, 14852.555555555557], [56.0, 13696.3], [57.0, 18096.000000000004], [58.0, 22152.1875], [59.0, 15007.333333333334], [60.0, 14905.833333333334], [61.0, 21614.0], [62.0, 25154.416666666664], [63.0, 19058.2], [64.0, 24177.375], [65.0, 25753.333333333332], [66.0, 19926.083333333332], [67.0, 20986.625], [68.0, 12198.5], [69.0, 21314.0], [70.0, 26523.0], [71.0, 18968.214285714286], [73.0, 20021.1], [74.0, 25824.833333333332], [72.0, 20004.000000000004], [75.0, 27754.0], [76.0, 24347.750000000004], [77.0, 20632.882352941175], [78.0, 25228.833333333332], [79.0, 23962.909090909092], [80.0, 21786.5], [81.0, 21296.235294117647], [82.0, 17645.636363636368], [83.0, 22121.285714285714], [84.0, 14184.999999999998], [86.0, 14135.454545454546], [87.0, 23651.727272727276], [85.0, 27.0], [88.0, 12831.0], [89.0, 28743.4], [90.0, 10307.6], [91.0, 21694.0], [92.0, 9210.166666666668], [93.0, 27335.749999999996], [94.0, 24720.625], [95.0, 19179.7], [96.0, 25963.444444444445], [97.0, 21133.0], [98.0, 15361.500000000002], [99.0, 20620.7], [100.0, 22300.090909090908], [101.0, 23761.2], [102.0, 18858.909090909092], [103.0, 15547.599999999999], [104.0, 19960.777777777777], [105.0, 3057.3], [1.0, 1264.0]], "isOverall": false, "label": "HTTP Request", "isController": false}, {"data": [[49.84700000000002, 12708.606999999993]], "isOverall": false, "label": "HTTP Request-Aggregated", "isController": false}], "supportsControllersDiscrimination": true, "maxX": 105.0, "title": "Time VS Threads"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    axisLabel: "Number of active threads",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response times in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: { noColumns: 2,show: true, container: '#legendTimeVsThreads' },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s: At %x.2 active threads, Average response time was %y.2 ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesTimeVsThreads"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotTimesVsThreads"), dataset, options);
            // setup overview
            $.plot($("#overviewTimesVsThreads"), dataset, prepareOverviewOptions(options));
        }
};

// Time vs threads
function refreshTimeVsThreads(){
    var infos = timeVsThreadsInfos;
    prepareSeries(infos.data);
    if(isGraph($("#flotTimesVsThreads"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTimeVsThreads");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTimesVsThreads", "#overviewTimesVsThreads");
        $('#footerTimeVsThreads .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var bytesThroughputOverTimeInfos = {
        data : {"result": {"minY": 718.1, "minX": 1.52480334E12, "maxY": 26387.15, "series": [{"data": [[1.52480352E12, 24491.633333333335], [1.52480358E12, 26387.15], [1.5248034E12, 22686.9], [1.52480346E12, 20812.4], [1.52480334E12, 20688.516666666666]], "isOverall": false, "label": "Bytes received per second", "isController": false}, {"data": [[1.52480352E12, 1100.8], [1.52480358E12, 915.9], [1.5248034E12, 842.8], [1.52480346E12, 722.4], [1.52480334E12, 718.1]], "isOverall": false, "label": "Bytes sent per second", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.52480358E12, "title": "Bytes Throughput Over Time"}},
        getOptions : function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity) ,
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Bytes / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendBytesThroughputOverTime'
                },
                selection: {
                    mode: "xy"
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y"
                }
            };
        },
        createGraph : function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesBytesThroughputOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotBytesThroughputOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewBytesThroughputOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Bytes throughput Over Time
function refreshBytesThroughputOverTime(fixTimestamps) {
    var infos = bytesThroughputOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 36000000);
    }
    if(isGraph($("#flotBytesThroughputOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesBytesThroughputOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotBytesThroughputOverTime", "#overviewBytesThroughputOverTime");
        $('#footerBytesThroughputOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var responseTimesOverTimeInfos = {
        data: {"result": {"minY": 2531.5269461077824, "minX": 1.52480334E12, "maxY": 19765.300781250004, "series": [{"data": [[1.52480352E12, 19765.300781250004], [1.52480358E12, 13579.09859154931], [1.5248034E12, 6408.321428571427], [1.52480346E12, 18318.726190476187], [1.52480334E12, 2531.5269461077824]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.52480358E12, "title": "Response Time Over Time"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average response time was %y ms"
                }
            };
        },
        createGraph: function() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Times Over Time
function refreshResponseTimeOverTime(fixTimestamps) {
    var infos = responseTimesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 36000000);
    }
    if(isGraph($("#flotResponseTimesOverTime"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesResponseTimesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimesOverTime", "#overviewResponseTimesOverTime");
        $('#footerResponseTimesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var latenciesOverTimeInfos = {
        data: {"result": {"minY": 2531.467065868262, "minX": 1.52480334E12, "maxY": 19765.285156249975, "series": [{"data": [[1.52480352E12, 19765.285156249975], [1.52480358E12, 13579.079812206577], [1.5248034E12, 6408.295918367348], [1.52480346E12, 18318.720238095237], [1.52480334E12, 2531.467065868262]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.52480358E12, "title": "Latencies Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average response latencies in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendLatenciesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average latency was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesLatenciesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotLatenciesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewLatenciesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Latencies Over Time
function refreshLatenciesOverTime(fixTimestamps) {
    var infos = latenciesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 36000000);
    }
    if(isGraph($("#flotLatenciesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesLatenciesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotLatenciesOverTime", "#overviewLatenciesOverTime");
        $('#footerLatenciesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var connectTimeOverTimeInfos = {
        data: {"result": {"minY": 26.868263473053894, "minX": 1.52480334E12, "maxY": 103.35211267605638, "series": [{"data": [[1.52480352E12, 53.99218749999999], [1.52480358E12, 103.35211267605638], [1.5248034E12, 30.464285714285715], [1.52480346E12, 27.30952380952381], [1.52480334E12, 26.868263473053894]], "isOverall": false, "label": "HTTP Request", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.52480358E12, "title": "Connect Time Over Time"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getConnectTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Average Connect Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendConnectTimeOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Average connect time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesConnectTimeOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotConnectTimeOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewConnectTimeOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Connect Time Over Time
function refreshConnectTimeOverTime(fixTimestamps) {
    var infos = connectTimeOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 36000000);
    }
    if(isGraph($("#flotConnectTimeOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesConnectTimeOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotConnectTimeOverTime", "#overviewConnectTimeOverTime");
        $('#footerConnectTimeOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var responseTimePercentilesOverTimeInfos = {
        data: {"result": {"minY": 1262.0, "minX": 1.52480334E12, "maxY": 41100.0, "series": [{"data": [[1.52480352E12, 37199.0], [1.52480358E12, 41100.0], [1.5248034E12, 13277.0], [1.52480346E12, 27362.0], [1.52480334E12, 4597.0]], "isOverall": false, "label": "Max", "isController": false}, {"data": [[1.52480352E12, 1262.0], [1.52480358E12, 1264.0], [1.5248034E12, 2058.0], [1.52480346E12, 10757.0], [1.52480334E12, 1276.0]], "isOverall": false, "label": "Min", "isController": false}, {"data": [[1.52480352E12, 30734.4], [1.52480358E12, 32068.0], [1.5248034E12, 10482.300000000005], [1.52480346E12, 21229.4], [1.52480334E12, 3581.2000000000003]], "isOverall": false, "label": "90th percentile", "isController": false}, {"data": [[1.52480352E12, 35504.54], [1.52480358E12, 37947.74], [1.5248034E12, 12618.760000000006], [1.52480346E12, 24784.509999999984], [1.52480334E12, 4327.039999999997]], "isOverall": false, "label": "99th percentile", "isController": false}, {"data": [[1.52480352E12, 33302.0], [1.52480358E12, 34777.799999999996], [1.5248034E12, 11122.3], [1.52480346E12, 22818.449999999997], [1.52480334E12, 3832.2]], "isOverall": false, "label": "95th percentile", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.52480358E12, "title": "Response Time Percentiles Over Time (successful requests only)"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true,
                        fill: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Response Time in ms",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: '#legendResponseTimePercentilesOverTime'
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s : at %x Response time was %y ms"
                }
            };
        },
        createGraph: function () {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesResponseTimePercentilesOverTime"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotResponseTimePercentilesOverTime"), dataset, options);
            // setup overview
            $.plot($("#overviewResponseTimePercentilesOverTime"), dataset, prepareOverviewOptions(options));
        }
};

// Response Time Percentiles Over Time
function refreshResponseTimePercentilesOverTime(fixTimestamps) {
    var infos = responseTimePercentilesOverTimeInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 36000000);
    }
    if(isGraph($("#flotResponseTimePercentilesOverTime"))) {
        infos.createGraph();
    }else {
        var choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimePercentilesOverTime", "#overviewResponseTimePercentilesOverTime");
        $('#footerResponseTimePercentilesOverTime .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var responseTimeVsRequestInfos = {
    data: {"result": {"minY": 35.0, "minX": 2.0, "maxY": 28696.0, "series": [{"data": [[2.0, 10757.0], [4.0, 28696.0], [3.0, 8758.5]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[4.0, 35.0], [3.0, 2254.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 4.0, "title": "Response Time Vs Request"}},
    getOptions: function() {
        return {
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Response Time in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: {
                noColumns: 2,
                show: true,
                container: '#legendResponseTimeVsRequest'
            },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesResponseTimeVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotResponseTimeVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewResponseTimeVsRequest"), dataset, prepareOverviewOptions(options));

    }
};

// Response Time vs Request
function refreshResponseTimeVsRequest() {
    var infos = responseTimeVsRequestInfos;
    prepareSeries(infos.data);
    if (isGraph($("#flotResponseTimeVsRequest"))){
        infos.create();
    }else{
        var choiceContainer = $("#choicesResponseTimeVsRequest");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotResponseTimeVsRequest", "#overviewResponseTimeVsRequest");
        $('#footerResponseRimeVsRequest .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};


var latenciesVsRequestInfos = {
    data: {"result": {"minY": 35.0, "minX": 2.0, "maxY": 28696.0, "series": [{"data": [[2.0, 10757.0], [4.0, 28696.0], [3.0, 8758.5]], "isOverall": false, "label": "Successes", "isController": false}, {"data": [[4.0, 35.0], [3.0, 2254.0]], "isOverall": false, "label": "Failures", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 4.0, "title": "Latencies Vs Request"}},
    getOptions: function() {
        return{
            series: {
                lines: {
                    show: false
                },
                points: {
                    show: true
                }
            },
            xaxis: {
                axisLabel: "Global number of requests per second",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            yaxis: {
                axisLabel: "Median Latency in ms",
                axisLabelUseCanvas: true,
                axisLabelFontSizePixels: 12,
                axisLabelFontFamily: 'Verdana, Arial',
                axisLabelPadding: 20,
            },
            legend: { noColumns: 2,show: true, container: '#legendLatencyVsRequest' },
            selection: {
                mode: 'xy'
            },
            grid: {
                hoverable: true // IMPORTANT! this is needed for tooltip to work
            },
            tooltip: true,
            tooltipOpts: {
                content: "%s : Median response time at %x req/s was %y ms"
            },
            colors: ["#9ACD32", "#FF6347"]
        };
    },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesLatencyVsRequest"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotLatenciesVsRequest"), dataset, options);
        // setup overview
        $.plot($("#overviewLatenciesVsRequest"), dataset, prepareOverviewOptions(options));
    }
};

// Latencies vs Request
function refreshLatenciesVsRequest() {
        var infos = latenciesVsRequestInfos;
        prepareSeries(infos.data);
        if(isGraph($("#flotLatenciesVsRequest"))){
            infos.createGraph();
        }else{
            var choiceContainer = $("#choicesLatencyVsRequest");
            createLegend(choiceContainer, infos);
            infos.createGraph();
            setGraphZoomable("#flotLatenciesVsRequest", "#overviewLatenciesVsRequest");
            $('#footerLatenciesVsRequest .legendColorBox > div').each(function(i){
                $(this).clone().prependTo(choiceContainer.find("li").eq(i));
            });
        }
};

var hitsPerSecondInfos = {
        data: {"result": {"minY": 2.35, "minX": 1.52480334E12, "maxY": 4.1, "series": [{"data": [[1.52480352E12, 4.1], [1.52480358E12, 2.35], [1.5248034E12, 3.716666666666667], [1.52480346E12, 3.45], [1.52480334E12, 3.05]], "isOverall": false, "label": "hitsPerSecond", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.52480358E12, "title": "Hits Per Second"}},
        getOptions: function() {
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of hits / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendHitsPerSecond"
                },
                selection: {
                    mode : 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y.2 hits/sec"
                }
            };
        },
        createGraph: function createGraph() {
            var data = this.data;
            var dataset = prepareData(data.result.series, $("#choicesHitsPerSecond"));
            var options = this.getOptions();
            prepareOptions(options, data);
            $.plot($("#flotHitsPerSecond"), dataset, options);
            // setup overview
            $.plot($("#overviewHitsPerSecond"), dataset, prepareOverviewOptions(options));
        }
};

// Hits per second
function refreshHitsPerSecond(fixTimestamps) {
    var infos = hitsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 36000000);
    }
    if (isGraph($("#flotHitsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesHitsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotHitsPerSecond", "#overviewHitsPerSecond");
        $('#footerHitsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
}

var codesPerSecondInfos = {
        data: {"result": {"minY": 0.21666666666666667, "minX": 1.52480334E12, "maxY": 3.55, "series": [{"data": [[1.52480352E12, 3.25], [1.52480358E12, 3.55], [1.5248034E12, 3.05], [1.52480346E12, 2.8], [1.52480334E12, 2.783333333333333]], "isOverall": false, "label": "200", "isController": false}, {"data": [[1.52480352E12, 0.7333333333333333]], "isOverall": false, "label": "404", "isController": false}, {"data": [[1.52480352E12, 0.2833333333333333], [1.5248034E12, 0.21666666666666667]], "isOverall": false, "label": "504", "isController": false}], "supportsControllersDiscrimination": false, "granularity": 60000, "maxX": 1.52480358E12, "title": "Codes Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of responses / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendCodesPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "Number of Response Codes %s at %x was %y.2 responses / sec"
                }
            };
        },
    createGraph: function() {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesCodesPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotCodesPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewCodesPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Codes per second
function refreshCodesPerSecond(fixTimestamps) {
    var infos = codesPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 36000000);
    }
    if(isGraph($("#flotCodesPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesCodesPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotCodesPerSecond", "#overviewCodesPerSecond");
        $('#footerCodesPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

var transactionsPerSecondInfos = {
        data: {"result": {"minY": 0.21666666666666667, "minX": 1.52480334E12, "maxY": 3.55, "series": [{"data": [[1.52480352E12, 3.25], [1.52480358E12, 3.55], [1.5248034E12, 3.05], [1.52480346E12, 2.8], [1.52480334E12, 2.783333333333333]], "isOverall": false, "label": "HTTP Request-success", "isController": false}, {"data": [[1.52480352E12, 1.0166666666666666], [1.5248034E12, 0.21666666666666667]], "isOverall": false, "label": "HTTP Request-failure", "isController": false}], "supportsControllersDiscrimination": true, "granularity": 60000, "maxX": 1.52480358E12, "title": "Transactions Per Second"}},
        getOptions: function(){
            return {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%H:%M:%S",
                    axisLabel: getElapsedTimeLabel(this.data.result.granularity),
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20,
                },
                yaxis: {
                    axisLabel: "Number of transactions / sec",
                    axisLabelUseCanvas: true,
                    axisLabelFontSizePixels: 12,
                    axisLabelFontFamily: 'Verdana, Arial',
                    axisLabelPadding: 20
                },
                legend: {
                    noColumns: 2,
                    show: true,
                    container: "#legendTransactionsPerSecond"
                },
                selection: {
                    mode: 'xy'
                },
                grid: {
                    hoverable: true // IMPORTANT! this is needed for tooltip to
                                    // work
                },
                tooltip: true,
                tooltipOpts: {
                    content: "%s at %x was %y transactions / sec"
                }
            };
        },
    createGraph: function () {
        var data = this.data;
        var dataset = prepareData(data.result.series, $("#choicesTransactionsPerSecond"));
        var options = this.getOptions();
        prepareOptions(options, data);
        $.plot($("#flotTransactionsPerSecond"), dataset, options);
        // setup overview
        $.plot($("#overviewTransactionsPerSecond"), dataset, prepareOverviewOptions(options));
    }
};

// Transactions per second
function refreshTransactionsPerSecond(fixTimestamps) {
    var infos = transactionsPerSecondInfos;
    prepareSeries(infos.data);
    if(fixTimestamps) {
        fixTimeStamps(infos.data.result.series, 36000000);
    }
    if(isGraph($("#flotTransactionsPerSecond"))){
        infos.createGraph();
    }else{
        var choiceContainer = $("#choicesTransactionsPerSecond");
        createLegend(choiceContainer, infos);
        infos.createGraph();
        setGraphZoomable("#flotTransactionsPerSecond", "#overviewTransactionsPerSecond");
        $('#footerTransactionsPerSecond .legendColorBox > div').each(function(i){
            $(this).clone().prependTo(choiceContainer.find("li").eq(i));
        });
    }
};

// Collapse the graph matching the specified DOM element depending the collapsed
// status
function collapse(elem, collapsed){
    if(collapsed){
        $(elem).parent().find(".fa-chevron-up").removeClass("fa-chevron-up").addClass("fa-chevron-down");
    } else {
        $(elem).parent().find(".fa-chevron-down").removeClass("fa-chevron-down").addClass("fa-chevron-up");
        if (elem.id == "bodyBytesThroughputOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshBytesThroughputOverTime(true);
            }
            document.location.href="#bytesThroughputOverTime";
        } else if (elem.id == "bodyLatenciesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesOverTime(true);
            }
            document.location.href="#latenciesOverTime";
        } else if (elem.id == "bodyConnectTimeOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshConnectTimeOverTime(true);
            }
            document.location.href="#connectTimeOverTime";
        } else if (elem.id == "bodyResponseTimePercentilesOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimePercentilesOverTime(true);
            }
            document.location.href="#responseTimePercentilesOverTime";
        } else if (elem.id == "bodyResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeDistribution();
            }
            document.location.href="#responseTimeDistribution" ;
        } else if (elem.id == "bodySyntheticResponseTimeDistribution") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshSyntheticResponseTimeDistribution();
            }
            document.location.href="#syntheticResponseTimeDistribution" ;
        } else if (elem.id == "bodyActiveThreadsOverTime") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshActiveThreadsOverTime(true);
            }
            document.location.href="#activeThreadsOverTime";
        } else if (elem.id == "bodyTimeVsThreads") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTimeVsThreads();
            }
            document.location.href="#timeVsThreads" ;
        } else if (elem.id == "bodyCodesPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshCodesPerSecond(true);
            }
            document.location.href="#codesPerSecond";
        } else if (elem.id == "bodyTransactionsPerSecond") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshTransactionsPerSecond(true);
            }
            document.location.href="#transactionsPerSecond";
        } else if (elem.id == "bodyResponseTimeVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshResponseTimeVsRequest();
            }
            document.location.href="#responseTimeVsRequest";
        } else if (elem.id == "bodyLatenciesVsRequest") {
            if (isGraph($(elem).find('.flot-chart-content')) == false) {
                refreshLatenciesVsRequest();
            }
            document.location.href="#latencyVsRequest";
        }
    }
}

// Collapse
$(function() {
        $('.collapse').on('shown.bs.collapse', function(){
            collapse(this, false);
        }).on('hidden.bs.collapse', function(){
            collapse(this, true);
        });
});

$(function() {
    $(".glyphicon").mousedown( function(event){
        var tmp = $('.in:not(ul)');
        tmp.parent().parent().parent().find(".fa-chevron-up").removeClass("fa-chevron-down").addClass("fa-chevron-down");
        tmp.removeClass("in");
        tmp.addClass("out");
    });
});

/*
 * Activates or deactivates all series of the specified graph (represented by id parameter)
 * depending on checked argument.
 */
function toggleAll(id, checked){
    var placeholder = document.getElementById(id);

    var cases = $(placeholder).find(':checkbox');
    cases.prop('checked', checked);
    $(cases).parent().children().children().toggleClass("legend-disabled", !checked);

    var choiceContainer;
    if ( id == "choicesBytesThroughputOverTime"){
        choiceContainer = $("#choicesBytesThroughputOverTime");
        refreshBytesThroughputOverTime(false);
    } else if(id == "choicesResponseTimesOverTime"){
        choiceContainer = $("#choicesResponseTimesOverTime");
        refreshResponseTimeOverTime(false);
    } else if ( id == "choicesLatenciesOverTime"){
        choiceContainer = $("#choicesLatenciesOverTime");
        refreshLatenciesOverTime(false);
    } else if ( id == "choicesConnectTimeOverTime"){
        choiceContainer = $("#choicesConnectTimeOverTime");
        refreshConnectTimeOverTime(false);
    } else if ( id == "responseTimePercentilesOverTime"){
        choiceContainer = $("#choicesResponseTimePercentilesOverTime");
        refreshResponseTimePercentilesOverTime(false);
    } else if ( id == "choicesResponseTimePercentiles"){
        choiceContainer = $("#choicesResponseTimePercentiles");
        refreshResponseTimePercentiles();
    } else if(id == "choicesActiveThreadsOverTime"){
        choiceContainer = $("#choicesActiveThreadsOverTime");
        refreshActiveThreadsOverTime(false);
    } else if ( id == "choicesTimeVsThreads"){
        choiceContainer = $("#choicesTimeVsThreads");
        refreshTimeVsThreads();
    } else if ( id == "choicesSyntheticResponseTimeDistribution"){
        choiceContainer = $("#choicesSyntheticResponseTimeDistribution");
        refreshSyntheticResponseTimeDistribution();
    } else if ( id == "choicesResponseTimeDistribution"){
        choiceContainer = $("#choicesResponseTimeDistribution");
        refreshResponseTimeDistribution();
    } else if ( id == "choicesHitsPerSecond"){
        choiceContainer = $("#choicesHitsPerSecond");
        refreshHitsPerSecond(false);
    } else if(id == "choicesCodesPerSecond"){
        choiceContainer = $("#choicesCodesPerSecond");
        refreshCodesPerSecond(false);
    } else if ( id == "choicesTransactionsPerSecond"){
        choiceContainer = $("#choicesTransactionsPerSecond");
        refreshTransactionsPerSecond(false);
    } else if ( id == "choicesResponseTimeVsRequest"){
        choiceContainer = $("#choicesResponseTimeVsRequest");
        refreshResponseTimeVsRequest();
    } else if ( id == "choicesLatencyVsRequest"){
        choiceContainer = $("#choicesLatencyVsRequest");
        refreshLatenciesVsRequest();
    }
    var color = checked ? "black" : "#818181";
    choiceContainer.find("label").each(function(){
        this.style.color = color;
    });
}

// Unchecks all boxes for "Hide all samples" functionality
function uncheckAll(id){
    toggleAll(id, false);
}

// Checks all boxes for "Show all samples" functionality
function checkAll(id){
    toggleAll(id, true);
}

// Prepares data to be consumed by plot plugins
function prepareData(series, choiceContainer, customizeSeries){
    var datasets = [];

    // Add only selected series to the data set
    choiceContainer.find("input:checked").each(function (index, item) {
        var key = $(item).attr("name");
        var i = 0;
        var size = series.length;
        while(i < size && series[i].label != key)
            i++;
        if(i < size){
            var currentSeries = series[i];
            datasets.push(currentSeries);
            if(customizeSeries)
                customizeSeries(currentSeries);
        }
    });
    return datasets;
}

/*
 * Ignore case comparator
 */
function sortAlphaCaseless(a,b){
    return a.toLowerCase() > b.toLowerCase() ? 1 : -1;
};

/*
 * Creates a legend in the specified element with graph information
 */
function createLegend(choiceContainer, infos) {
    // Sort series by name
    var keys = [];
    $.each(infos.data.result.series, function(index, series){
        keys.push(series.label);
    });
    keys.sort(sortAlphaCaseless);

    // Create list of series with support of activation/deactivation
    $.each(keys, function(index, key) {
        var id = choiceContainer.attr('id') + index;
        $('<li />')
            .append($('<input id="' + id + '" name="' + key + '" type="checkbox" checked="checked" hidden />'))
            .append($('<label />', { 'text': key , 'for': id }))
            .appendTo(choiceContainer);
    });
    choiceContainer.find("label").click( function(){
        if (this.style.color !== "rgb(129, 129, 129)" ){
            this.style.color="#818181";
        }else {
            this.style.color="black";
        }
        $(this).parent().children().children().toggleClass("legend-disabled");
    });
    choiceContainer.find("label").mousedown( function(event){
        event.preventDefault();
    });
    choiceContainer.find("label").mouseenter(function(){
        this.style.cursor="pointer";
    });

    // Recreate graphe on series activation toggle
    choiceContainer.find("input").click(function(){
        infos.createGraph();
    });
}
